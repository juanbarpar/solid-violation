public class GestionEnvio {

    private void crearTipoEnvio(TipoEnvio envio) {
        //Save Envio DB
    }

}
