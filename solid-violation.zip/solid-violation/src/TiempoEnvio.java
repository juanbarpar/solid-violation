public interface TiempoEnvio {

    String getTiempo();
}
