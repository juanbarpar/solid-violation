public class TipoEnvio {

    private String tipo;
    public TipoEnvio(String tipo) {
        this.tipo = tipo;
    }
    public TipoEnvio() {

    }



}
